import React, { useCallback, useEffect, useRef, useState } from 'react';
import { ActivityIndicator, AppState, BackHandler, Linking, StatusBar, StyleSheet, View } from 'react-native';
import { WebView } from 'react-native-webview';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import * as FileSystem from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import * as Notifications from 'expo-notifications';
import * as LocalAuthentication from 'expo-local-authentication';
import APP_HTML, { BUILD } from './src/appHtml';

// The shop app runs inside this screen. Records stay on the phone (and in Firebase when it is set up).
const BASE = 'https://thanga-maaligai.app/';

// In-app updates: a newer app page downloaded from the shop's website is kept here and used instead of the built-in one.
const UPD_HTML = FileSystem.documentDirectory + 'tmf-app.html';
const UPD_META = FileSystem.documentDirectory + 'tmf-app.json';
async function loadAppPage() {
  try {
    const m = JSON.parse(await FileSystem.readAsStringAsync(UPD_META));
    if (m && m.hash !== BUILD.hash && String(m.builtAt) > String(BUILD.builtAt)) {
      const h = await FileSystem.readAsStringAsync(UPD_HTML);
      if (h && h.length > 5000 && h.includes('APP_BUILD')) return { html: h, hash: m.hash };
    }
  } catch (e) {}
  return { html: APP_HTML, hash: BUILD.hash };
}

// Show reminders even when the app is open.
Notifications.setNotificationHandler({
  handleNotification: async () => ({ shouldShowAlert: true, shouldPlaySound: true, shouldSetBadge: false }),
});

// Every day at 6 pm (phone time, IST in India): end-of-day reminder for everyone who uses this phone.
async function setupDailyReminder() {
  try {
    await Notifications.setNotificationChannelAsync('shop', {
      name: 'Shop reminders',
      importance: Notifications.AndroidImportance.HIGH,
      sound: 'default',
    });
    const perm = await Notifications.requestPermissionsAsync();
    if (perm.status !== 'granted') return false;
    await Notifications.cancelScheduledNotificationAsync('eod-daily').catch(() => {});
    await Notifications.scheduleNotificationAsync({
      identifier: 'eod-daily',
      content: { title: '🌙 6 pm – close the day', body: 'Update stock, enter today’s expenses and check the end of day report.' },
      trigger: { hour: 18, minute: 0, repeats: true, channelId: 'shop' },
    });
    return true;
  } catch (e) { return false; }
}

// Loan due dates, customer promise dates and order dates sent from the shop app.
async function scheduleReminders(list) {
  try {
    const all = await Notifications.getAllScheduledNotificationsAsync();
    for (const n of all) if (String(n.identifier).startsWith('r-')) await Notifications.cancelScheduledNotificationAsync(n.identifier);
    const now = Date.now();
    for (const r of list || []) {
      if (!r || !(r.at > now)) continue;
      await Notifications.scheduleNotificationAsync({
        identifier: 'r-' + r.id,
        content: { title: String(r.title || 'Reminder'), body: String(r.body || '') },
        trigger: { date: new Date(r.at), channelId: 'shop' },
      });
    }
  } catch (e) {}
}

export default function App() {
  const web = useRef(null);
  const [page, setPage] = useState(null);
  useEffect(() => { loadAppPage().then(setPage); }, []);

  useEffect(() => { setupDailyReminder(); }, []);

  // Security: lock TMF again when it comes back after more than 1 minute in the background.
  useEffect(() => {
    let left = 0;
    const sub = AppState.addEventListener('change', (st) => {
      if (st === 'background') left = Date.now();
      if (st === 'active' && left) {
        const away = Date.now() - left; left = 0;
        web.current?.injectJavaScript(`window.onNative&&window.onNative({t:'resume',away:${away}});true;`);
      }
    });
    return () => sub.remove();
  }, []);

  // Android back button: close a pop-up or go back to Today; exit only from Today.
  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      web.current?.injectJavaScript(
        "(function(){var h=window.appBack&&window.appBack();if(!h)window.ReactNativeWebView.postMessage(JSON.stringify({t:'exit'}));})();true;"
      );
      return true;
    });
    return () => sub.remove();
  }, []);

  // Messages from the shop app: share a bill PDF or backup file, or exit.
  const onMessage = useCallback(async (e) => {
    let m;
    try { m = JSON.parse(e.nativeEvent.data); } catch { return; }
    if (m.t === 'exit') BackHandler.exitApp();
    if (m.t === 'reminders') { scheduleReminders(m.list); return; }
    if (m.t === 'update') {
      try {
        if (!m.html || !String(m.html).includes('APP_BUILD')) return;
        await FileSystem.writeAsStringAsync(UPD_HTML, m.html);
        await FileSystem.writeAsStringAsync(UPD_META, JSON.stringify({ hash: m.hash, builtAt: m.builtAt }));
        setPage({ html: m.html, hash: m.hash });
      } catch (err) {}
      return;
    }
    const reply = (o) => web.current?.injectJavaScript(`window.onNative&&window.onNative(${JSON.stringify(o)});true;`);
    if (m.t === 'bio-avail') {
      try { const ok = (await LocalAuthentication.hasHardwareAsync()) && (await LocalAuthentication.isEnrolledAsync()); reply({ t: 'bio-avail', ok }); }
      catch (err) { reply({ t: 'bio-avail', ok: false }); }
      return;
    }
    if (m.t === 'bio') {
      try {
        const r = await LocalAuthentication.authenticateAsync({ promptMessage: 'Unlock TMF', cancelLabel: 'Use password', disableDeviceFallback: false });
        reply({ t: 'bio', ok: !!r.success });
      } catch (err) { reply({ t: 'bio', ok: false }); }
      return;
    }
    if (m.t === 'share') {
      try {
        const uri = FileSystem.cacheDirectory + String(m.name).replace(/[^\w.\- ]/g, '_');
        await FileSystem.writeAsStringAsync(uri, m.b64, { encoding: FileSystem.EncodingType.Base64 });
        if (await Sharing.isAvailableAsync()) await Sharing.shareAsync(uri, { mimeType: m.mime, dialogTitle: m.name });
      } catch (err) {}
    }
  }, []);

  // WhatsApp and other outside links open in their own apps.
  const onNav = useCallback((req) => {
    const u = req.url || '';
    if (u.startsWith(BASE) || u.startsWith('about:') || u.startsWith('data:') || u.startsWith('blob:')) return true;
    Linking.openURL(u).catch(() => {});
    return false;
  }, []);

  return (
    <SafeAreaProvider>
      <StatusBar barStyle="light-content" backgroundColor="#0C3B3F" />
      <SafeAreaView style={styles.root} edges={['top', 'bottom']}>
        {!page ? (
          <View style={[styles.root, { alignItems: 'center', justifyContent: 'center' }]}><ActivityIndicator color="#E2B44B" size="large" /></View>
        ) : (
        <WebView
          key={page.hash}
          ref={web}
          style={styles.root}
          originWhitelist={['*']}
          source={{ html: page.html, baseUrl: BASE }}
          javaScriptEnabled
          domStorageEnabled
          allowFileAccess
          setSupportMultipleWindows={false}
          textZoom={100}
          onMessage={onMessage}
          onShouldStartLoadWithRequest={onNav}
        />
        )}
      </SafeAreaView>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({ root: { flex: 1, backgroundColor: '#0C3B3F' } });
