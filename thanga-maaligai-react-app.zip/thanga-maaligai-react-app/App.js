import React, { useCallback, useEffect, useRef } from 'react';
import { BackHandler, Linking, StatusBar, StyleSheet } from 'react-native';
import { WebView } from 'react-native-webview';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import * as FileSystem from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import APP_HTML from './src/appHtml';

// The shop app runs inside this screen. Records stay on the phone (and in Firebase when it is set up).
const BASE = 'https://thanga-maaligai.app/';

export default function App() {
  const web = useRef(null);

  // Android back button: close a pop-up or go back to Today; exit only from Today.
  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      web.current?.injectJavaScript(
        "(function(){var h=window.appBack&&window.appBack();if(!h)window.ReactNativeWebView.postMessage(JSON.stringify({t:'exit'}));})();true;"
      );
      return true;
    });
    return () => sub.remove();
  }, []);

  // Messages from the shop app: share a bill PDF or backup file, or exit.
  const onMessage = useCallback(async (e) => {
    let m;
    try { m = JSON.parse(e.nativeEvent.data); } catch { return; }
    if (m.t === 'exit') BackHandler.exitApp();
    if (m.t === 'share') {
      try {
        const uri = FileSystem.cacheDirectory + String(m.name).replace(/[^\w.\- ]/g, '_');
        await FileSystem.writeAsStringAsync(uri, m.b64, { encoding: FileSystem.EncodingType.Base64 });
        if (await Sharing.isAvailableAsync()) await Sharing.shareAsync(uri, { mimeType: m.mime, dialogTitle: m.name });
      } catch (err) {}
    }
  }, []);

  // WhatsApp and other outside links open in their own apps.
  const onNav = useCallback((req) => {
    const u = req.url || '';
    if (u.startsWith(BASE) || u.startsWith('about:') || u.startsWith('data:') || u.startsWith('blob:')) return true;
    Linking.openURL(u).catch(() => {});
    return false;
  }, []);

  return (
    <SafeAreaProvider>
      <StatusBar barStyle="light-content" backgroundColor="#0C3B3F" />
      <SafeAreaView style={styles.root} edges={['top', 'bottom']}>
        <WebView
          ref={web}
          style={styles.root}
          originWhitelist={['*']}
          source={{ html: APP_HTML, baseUrl: BASE }}
          javaScriptEnabled
          domStorageEnabled
          allowFileAccess
          setSupportMultipleWindows={false}
          textZoom={100}
          onMessage={onMessage}
          onShouldStartLoadWithRequest={onNav}
        />
      </SafeAreaView>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({ root: { flex: 1, backgroundColor: '#0C3B3F' } });
