// Builds src/appHtml.js from web/shop.html + config.js (runs automatically on GitHub).
const fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..');
const cfg = require(path.join(root, 'config.js'));
const body = fs.readFileSync(path.join(root, 'web', 'shop.html'), 'utf8');
const FB = 'https://www.gstatic.com/firebasejs/10.12.2/';
const html = `<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover,maximum-scale=1">
<title>Thirumagal Thanga Maaligai</title>
<style>:root{color-scheme:light}body{margin:0;font:14px/1.5 system-ui,-apple-system,"Segoe UI",sans-serif;background:#F4EADC}img{max-width:100%}[hidden]{display:none!important}</style>
<script>window.FIREBASE_CONFIG=${JSON.stringify(cfg.FIREBASE_CONFIG || null)};window.OWNER_EMAIL=${JSON.stringify(cfg.OWNER_EMAIL || '')};</script>
<script>if(window.FIREBASE_CONFIG){document.write('<script src="${FB}firebase-app-compat.js"><\\/script><script src="${FB}firebase-auth-compat.js"><\\/script><script src="${FB}firebase-firestore-compat.js"><\\/script>')}</script>
</head><body>
${body}
</body></html>`;
fs.writeFileSync(path.join(root, 'src', 'appHtml.js'), 'export default ' + JSON.stringify(html) + ';\n');
console.log('Built src/appHtml.js (' + Math.round(html.length / 1024) + ' KB), Firebase ' + (cfg.FIREBASE_CONFIG ? 'ON' : 'off'));
