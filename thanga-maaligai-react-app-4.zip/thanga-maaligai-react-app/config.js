/* ===== Thirumagal Thanga Maaligai — online settings =====
   Leave FIREBASE_CONFIG as null to keep records only on each phone.
   To turn on email login + automatic cloud backup, paste your Firebase
   web app settings (Firebase > Project settings > Your apps > Config) and the owner's email.
   After you change this file on GitHub, a new app is built automatically. */
module.exports = {
  FIREBASE_CONFIG: null,
  /* Example:
  FIREBASE_CONFIG: {
    apiKey: "AIza....",
    authDomain: "thanga-maaligai.firebaseapp.com",
    projectId: "thanga-maaligai",
    storageBucket: "thanga-maaligai.appspot.com",
    messagingSenderId: "1234567890",
    appId: "1:1234567890:web:abc123"
  },
  */
  OWNER_EMAIL: "",   // e.g. "owner@gmail.com" — this person is Owner / CEO
  /* Where the app downloads its updates from (your GitHub Pages site). */
  UPDATE_URL: "https://arunramanan785.github.io/thanga-maaligai-app/"
};
