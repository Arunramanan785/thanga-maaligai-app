# Thirumagal Thanga Maaligai — shop app (React Native)

Android app for billing, stock by tray/box, customers, suppliers and reports.

**To get the app:** open the **Releases** section on the right of this page and download `ThangaMaaligai.apk` from the latest one. Open it on the phone to install.

Every time a file here changes, GitHub builds a fresh app automatically (Actions tab, about 10–15 minutes).

- `config.js` — Firebase settings for email login and cloud backup (leave `null` to keep records only on each phone).
- `web/shop.html` — the shop app screens.
- `App.js` — the React Native app that runs them, handles the back button and sharing.
