// Shared: builds the full app page used by the Android app (and as the in-app update file).
const fs = require('fs'), path = require('path'), crypto = require('crypto');
const root = path.join(__dirname, '..');
module.exports = function makeAppHtml() {
  delete require.cache[require.resolve(path.join(root, 'config.js'))];
  const cfg = require(path.join(root, 'config.js'));
  const body = fs.readFileSync(path.join(root, 'web', 'shop.html'), 'utf8');
  const hash = crypto.createHash('sha1').update(body + JSON.stringify(cfg)).digest('hex').slice(0, 12);
  const builtAt = new Date().toISOString();
  const updateUrl = cfg.UPDATE_URL || '';
  const build = { hash, builtAt };
  const html = `<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover,maximum-scale=1">
<title>TMF · Thirumagal Thanga Maaligai</title>
<style>:root{color-scheme:light}body{margin:0;font:14px/1.5 system-ui,-apple-system,"Segoe UI",sans-serif;background:#F4EADC}img{max-width:100%}[hidden]{display:none!important}</style>
<script>window.FIREBASE_CONFIG=${JSON.stringify(cfg.FIREBASE_CONFIG || null)};window.OWNER_EMAIL=${JSON.stringify(cfg.OWNER_EMAIL || '')};window.APP_BUILD=${JSON.stringify(build)};window.UPDATE_URL=${JSON.stringify(updateUrl)};</script>
</head><body>
${body}
</body></html>`;
  return { html, build, cfg, body };
};
