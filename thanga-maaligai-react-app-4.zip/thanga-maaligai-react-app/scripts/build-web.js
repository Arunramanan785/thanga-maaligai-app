// Builds the laptop / browser version into ./site (published to GitHub Pages by the workflow).
const fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..'), out = path.join(root, 'site');
const app = require('./app-html')();
const cfg = app.cfg, body = app.body;
fs.rmSync(out, { recursive: true, force: true }); fs.mkdirSync(out, { recursive: true });
for (const f of fs.readdirSync(path.join(root, 'web', 'site'))) fs.copyFileSync(path.join(root, 'web', 'site', f), path.join(out, f));
const html = `<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>TMF · Thirumagal Thanga Maaligai</title>
<meta name="theme-color" content="#0C3B3F">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="TMF">
<link rel="manifest" href="manifest.webmanifest">
<link rel="icon" type="image/png" href="icon-192.png">
<link rel="apple-touch-icon" href="apple-touch-icon.png">
<style>:root{color-scheme:light}body{margin:0;font:14px/1.5 system-ui,-apple-system,"Segoe UI",sans-serif;background:#F4EADC}img{max-width:100%}[hidden]{display:none!important}</style>
<script>window.FIREBASE_CONFIG=${JSON.stringify(cfg.FIREBASE_CONFIG || null)};window.OWNER_EMAIL=${JSON.stringify(cfg.OWNER_EMAIL || '')};window.APP_BUILD=${JSON.stringify(app.build)};window.UPDATE_URL=${JSON.stringify(cfg.UPDATE_URL || '')};</script>
</head><body>
${body}
<script>if('serviceWorker' in navigator)addEventListener('load',()=>navigator.serviceWorker.register('sw.js').catch(()=>{}));</script>
</body></html>`;
fs.writeFileSync(path.join(out, 'index.html'), html);
fs.writeFileSync(path.join(out, '.nojekyll'), '');
// In-app update files for the Android app
fs.writeFileSync(path.join(out, 'app.html'), app.html);
fs.writeFileSync(path.join(out, 'version.json'), JSON.stringify({ ...app.build, file: 'app.html', size: app.html.length }));
console.log('Built site/ for laptop and browser (' + Math.round(html.length / 1024) + ' KB)');
