// Builds src/appHtml.js from web/shop.html + config.js (runs automatically on GitHub).
const fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..');
const { html, build, cfg } = require('./app-html')();
fs.writeFileSync(path.join(root, 'src', 'appHtml.js'), 'export const BUILD = ' + JSON.stringify(build) + ';\nexport default ' + JSON.stringify(html) + ';\n');
console.log('Built src/appHtml.js (' + Math.round(html.length / 1024) + ' KB), build ' + build.hash + ', Firebase ' + (cfg.FIREBASE_CONFIG ? 'ON' : 'off'));
